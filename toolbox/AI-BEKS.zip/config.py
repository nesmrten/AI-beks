import os

SECRET_KEY = 'Stargatesg-1aio!#$'
SQLALCHEMY_DATABASE_URI = 'sqlite:///db.sqlite3'
SQLALCHEMY_TRACK_MODIFICATIONS = False
