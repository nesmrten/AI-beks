from views.auth import auth
from views.main import main
from flask import Flask
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from models.model import db, init_app as init_db
from flask import current_app


app = Flask(__name__)
app.config['SECRET_KEY'] = 'Stargatesg-1aio!#$'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'

bcrypt = Bcrypt(app)
login_manager = LoginManager(app)

init_db(app)

with app.app_context():
    db.create_all()


app.register_blueprint(main)
app.register_blueprint(auth)


@login_manager.user_loader
def load_user(user_id):
    with current_app.app_context():
        return User.query.get(int(user_id))


if __name__ == '__main__':
    app.run(debug=True)
