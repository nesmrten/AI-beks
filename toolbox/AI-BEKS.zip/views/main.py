from flask import Blueprint, render_template, request, jsonify


main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/chat')
def chat():
    return render_template('chat.html')
  
@main.route('/get', methods=['POST'])
def get_bot_response():
    user_input = request.json['user_input']  # Get the user input from the JSON data
    
    # Your implementation for processing the user_input and generating a response
    bot_response = "This is a sample response."

    return jsonify({'response': bot_response})
