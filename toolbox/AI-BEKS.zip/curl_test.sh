curl -X POST \
  http://localhost:5000/api/chatbot \
  -H 'Content-Type: application/json' \
  -d '{"message": "Hi, can you help me with my order?"}'